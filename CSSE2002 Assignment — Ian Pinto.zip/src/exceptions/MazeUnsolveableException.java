package exceptions;

/**
 * Thrown when the autosolver cannot solve a maze.
 */
public class MazeUnsolveableException extends Exception {
}
